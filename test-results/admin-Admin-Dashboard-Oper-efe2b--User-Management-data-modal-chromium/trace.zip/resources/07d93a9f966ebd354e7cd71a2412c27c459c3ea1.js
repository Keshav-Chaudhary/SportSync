(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e57571bc._.js",
  "static/chunks/node_modules_85defd3d._.js"
],
    source: "dynamic"
});
