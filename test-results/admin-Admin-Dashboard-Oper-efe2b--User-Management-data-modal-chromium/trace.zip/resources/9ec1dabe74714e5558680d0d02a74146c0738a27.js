(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_2e99f05c._.js",
  "static/chunks/_66d4a05b._.js"
],
    source: "dynamic"
});
